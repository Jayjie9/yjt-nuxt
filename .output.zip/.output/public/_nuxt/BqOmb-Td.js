var r=(A=>(A.AVATAR="AVATAR",A.ID_CARD="ID_CARD",A.LICENSE="LICENSE",A))(r||{});export{r as F};
