import"./CtG9lFlj.js";const r=""+new URL("logo.ejBiKqzV.png",import.meta.url).href;export{r as _};
