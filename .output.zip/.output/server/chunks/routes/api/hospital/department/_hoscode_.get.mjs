import { c as defineEventHandler, g as getRouterParam } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const _hoscode__get = defineEventHandler(async (event) => {
  getRouterParam(event, "hoscode");
  try {
    const departmentList = [
      {
        depcode: "100",
        depname: "\u5185\u79D1",
        children: [
          {
            depcode: "1001",
            depname: "\u547C\u5438\u5185\u79D1",
            children: null
          },
          {
            depcode: "1002",
            depname: "\u6D88\u5316\u5185\u79D1",
            children: null
          },
          {
            depcode: "1003",
            depname: "\u795E\u7ECF\u5185\u79D1",
            children: null
          },
          {
            depcode: "1004",
            depname: "\u5FC3\u8840\u7BA1\u5185\u79D1",
            children: null
          }
        ]
      },
      {
        depcode: "200",
        depname: "\u5916\u79D1",
        children: [
          {
            depcode: "2001",
            depname: "\u666E\u901A\u5916\u79D1",
            children: null
          },
          {
            depcode: "2002",
            depname: "\u9AA8\u79D1",
            children: null
          },
          {
            depcode: "2003",
            depname: "\u6CCC\u5C3F\u5916\u79D1",
            children: null
          },
          {
            depcode: "2004",
            depname: "\u795E\u7ECF\u5916\u79D1",
            children: null
          }
        ]
      },
      {
        depcode: "300",
        depname: "\u5987\u4EA7\u79D1",
        children: [
          {
            depcode: "3001",
            depname: "\u5987\u79D1",
            children: null
          },
          {
            depcode: "3002",
            depname: "\u4EA7\u79D1",
            children: null
          }
        ]
      },
      {
        depcode: "400",
        depname: "\u513F\u79D1",
        children: [
          {
            depcode: "4001",
            depname: "\u5C0F\u513F\u5185\u79D1",
            children: null
          },
          {
            depcode: "4002",
            depname: "\u5C0F\u513F\u5916\u79D1",
            children: null
          },
          {
            depcode: "4003",
            depname: "\u65B0\u751F\u513F\u79D1",
            children: null
          }
        ]
      },
      {
        depcode: "500",
        depname: "\u6025\u8BCA\u533B\u5B66\u79D1",
        children: [
          {
            depcode: "5001",
            depname: "\u6025\u8BCA\u5185\u79D1",
            children: null
          },
          {
            depcode: "5002",
            depname: "\u6025\u8BCA\u5916\u79D1",
            children: null
          }
        ]
      }
    ];
    return {
      code: 200,
      message: "\u83B7\u53D6\u79D1\u5BA4\u5217\u8868\u6210\u529F",
      data: departmentList
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u79D1\u5BA4\u5217\u8868\u5931\u8D25", error);
    return {
      code: 500,
      message: "\u83B7\u53D6\u79D1\u5BA4\u5217\u8868\u5931\u8D25",
      data: null
    };
  }
});

export { _hoscode__get as default };
//# sourceMappingURL=_hoscode_.get.mjs.map
