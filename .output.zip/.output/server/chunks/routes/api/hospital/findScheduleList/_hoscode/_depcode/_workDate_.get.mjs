import { c as defineEventHandler, g as getRouterParam } from '../../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const _workDate__get = defineEventHandler(async (event) => {
  const hoscode = getRouterParam(event, "hoscode");
  const depcode = getRouterParam(event, "depcode");
  const workDate = getRouterParam(event, "workDate");
  try {
    const morningSchedules = Array.from({ length: 3 }, (_, index) => {
      return {
        id: `morning_${hoscode}_${depcode}_${workDate}_${index}`,
        workDate,
        workTime: 0,
        // 0表示上午
        title: `${index + 1}\u53F7\u8BCA\u5BA4`,
        docname: ["\u5F20\u533B\u751F", "\u674E\u533B\u751F", "\u738B\u533B\u751F"][index],
        skill: ["\u5E38\u89C1\u547C\u5438\u7CFB\u7EDF\u75BE\u75C5", "\u80BA\u90E8\u611F\u67D3", "\u6162\u6027\u963B\u585E\u6027\u80BA\u75BE\u75C5"][index],
        amount: 100 + Math.floor(Math.random() * 100),
        availableNumber: Math.floor(Math.random() * 20),
        reservedNumber: Math.floor(Math.random() * 10)
      };
    });
    const afternoonSchedules = Array.from({ length: 2 }, (_, index) => {
      return {
        id: `afternoon_${hoscode}_${depcode}_${workDate}_${index}`,
        workDate,
        workTime: 1,
        // 1表示下午
        title: `${index + 1}\u53F7\u8BCA\u5BA4`,
        docname: ["\u8D75\u533B\u751F", "\u94B1\u533B\u751F"][index],
        skill: ["\u54EE\u5598", "\u80BA\u7ED3\u6838"][index],
        amount: 120 + Math.floor(Math.random() * 100),
        availableNumber: Math.floor(Math.random() * 20),
        reservedNumber: Math.floor(Math.random() * 10)
      };
    });
    const schedules = [...morningSchedules, ...afternoonSchedules];
    return {
      code: 200,
      message: "\u83B7\u53D6\u6392\u73ED\u5217\u8868\u6210\u529F",
      data: schedules
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u6392\u73ED\u5217\u8868\u5931\u8D25", error);
    return {
      code: 500,
      message: "\u83B7\u53D6\u6392\u73ED\u5217\u8868\u5931\u8D25",
      data: null
    };
  }
});

export { _workDate__get as default };
//# sourceMappingURL=_workDate_.get.mjs.map
