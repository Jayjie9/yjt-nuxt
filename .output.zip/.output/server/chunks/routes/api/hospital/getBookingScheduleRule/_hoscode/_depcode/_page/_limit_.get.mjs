import { c as defineEventHandler, g as getRouterParam } from '../../../../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const _limit__get = defineEventHandler(async (event) => {
  const hoscode = getRouterParam(event, "hoscode");
  const depcode = getRouterParam(event, "depcode");
  parseInt(getRouterParam(event, "page") || "1");
  parseInt(getRouterParam(event, "limit") || "10");
  try {
    const currentDate = /* @__PURE__ */ new Date();
    const bookingScheduleList = Array.from({ length: 10 }, (_, index) => {
      const date = new Date(currentDate);
      date.setDate(currentDate.getDate() + index);
      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, "0");
      const day = date.getDate().toString().padStart(2, "0");
      const formattedDate = `${year}-${month}-${day}`;
      const weekdays = ["\u5468\u65E5", "\u5468\u4E00", "\u5468\u4E8C", "\u5468\u4E09", "\u5468\u56DB", "\u5468\u4E94", "\u5468\u516D"];
      const dayOfWeek = weekdays[date.getDay()];
      const availableNumber = Math.floor(Math.random() * 20);
      let status = 0;
      if (index === 0) {
        status = 0;
      } else if (index === 1) {
        status = 1;
      } else {
        status = Math.random() > 0.2 ? 0 : -1;
      }
      return {
        workDate: formattedDate,
        dayOfWeek,
        status,
        availableNumber: status === -1 ? -1 : availableNumber,
        reservedNumber: Math.floor(Math.random() * 10),
        id: `schedule_${hoscode}_${depcode}_${formattedDate}`
      };
    });
    const baseMap = {
      hosname: "\u5317\u4EAC\u534F\u548C\u533B\u9662",
      bigname: "\u5185\u79D1",
      depname: "\u547C\u5438\u5185\u79D1",
      workDateString: "\u79D1\u5BA4\u53EF\u9884\u7EA6\u65F6\u95F4",
      releaseTime: "08:30"
    };
    return {
      code: 200,
      message: "\u83B7\u53D6\u6392\u73ED\u89C4\u5219\u6210\u529F",
      data: {
        total: 30,
        // 总数据量
        bookingScheduleList,
        baseMap
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u6392\u73ED\u89C4\u5219\u5931\u8D25", error);
    return {
      code: 500,
      message: "\u83B7\u53D6\u6392\u73ED\u89C4\u5219\u5931\u8D25",
      data: null
    };
  }
});

export { _limit__get as default };
//# sourceMappingURL=_limit_.get.mjs.map
