import { c as defineEventHandler, g as getRouterParam } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const _phone__get = defineEventHandler(async (event) => {
  const phone = getRouterParam(event, "phone");
  if (!phone || !/^1[3456789]\d{9}$/.test(phone)) {
    return {
      code: 201,
      message: "\u624B\u673A\u53F7\u683C\u5F0F\u4E0D\u6B63\u786E",
      data: null
    };
  }
  Math.floor(1e5 + Math.random() * 9e5).toString();
  return {
    code: 200,
    message: "\u9A8C\u8BC1\u7801\u53D1\u9001\u6210\u529F",
    data: {
      phone,
      // 实际生产环境不应该返回验证码，这里仅用于测试
      code: void 0
    }
  };
});

export { _phone__get as default };
//# sourceMappingURL=_phone_.get.mjs.map
