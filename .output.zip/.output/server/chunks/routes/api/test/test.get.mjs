import { c as defineEventHandler } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const test_get = defineEventHandler(async (event) => {
  const response = await $fetch("http://127.0.0.1:8000/api/cmn/test/a", {
    method: "GET"
    // 对于简单的GET请求，通常不需要特别指定Content-Type header
  });
  return response;
});

export { test_get as default };
//# sourceMappingURL=test.get.mjs.map
