import { c as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!body.phone || !body.code) {
    return {
      code: 201,
      message: "\u624B\u673A\u53F7\u548C\u9A8C\u8BC1\u7801\u4E0D\u80FD\u4E3A\u7A7A",
      data: null
    };
  }
  if (!/^1[3456789]\d{9}$/.test(body.phone)) {
    return {
      code: 201,
      message: "\u624B\u673A\u53F7\u683C\u5F0F\u4E0D\u6B63\u786E",
      data: null
    };
  }
  return {
    code: 200,
    message: "\u767B\u5F55\u6210\u529F",
    data: {
      name: "\u6D4B\u8BD5\u7528\u6237",
      token: "mock-token-" + Date.now(),
      phone: body.phone
    }
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
